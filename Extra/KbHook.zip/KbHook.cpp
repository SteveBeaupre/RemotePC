#include "KbHook.h"

//the following is to allow the sharing of data between instances of this dll...
#pragma data_seg(".SHARDAT")
static HINSTANCE hInstance = NULL;
static HHOOK hHook = NULL;
static HWND hViewerWnd = NULL;
static void *OnKeyEvent = NULL;
#pragma data_seg()


///////////////////////////////////////////////////////////////////////////
// Dll Entry point
///////////////////////////////////////////////////////////////////////////
BOOL WINAPI DllMain(HINSTANCE hInst, DWORD fdwreason,  LPVOID lpReserved)
{
    switch(fdwreason)
	{
    case DLL_PROCESS_ATTACH:
		hInstance = hInst;
		break;
    case DLL_THREAD_ATTACH:  break;
    case DLL_THREAD_DETACH:  break;
    case DLL_PROCESS_DETACH: break;
    }
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// The keyboard hook callback
///////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK KeyboardProc(int code, WPARAM wParam, LPARAM lParam)
{
	if(code >= 0){

		// Get the cursor position
		POINT p;
		GetCursorPos(&p);

		// Check if the window under the cursor is the renderer window
		if(hViewerWnd == WindowFromPoint(p)){
		
			// If so, call the external function OnKeyEvent(DWORD wParam, DWORD lParam)
			if(OnKeyEvent != NULL){
				_asm {
					push lParam
					push wParam			

					call OnKeyEvent
					add esp, 8 
				}
			}

			// ... and disable the keyboard
			return 1;
		}
	}

	// Process key normally
	return CallNextHookEx(hHook, code, wParam, lParam);
}

///////////////////////////////////////////////////////////////////////////
// Install the hook...
///////////////////////////////////////////////////////////////////////////
BOOL WINAPI _InstallHook(HWND ViewerWnd, void *pKeyEventFunc)
{
	if(!hHook){

		hViewerWnd = ViewerWnd;
		OnKeyEvent = pKeyEventFunc;

		hHook = SetWindowsHookEx(WH_KEYBOARD_LL, (HOOKPROC)KeyboardProc, hInstance, 0);
	}

	return hHook != NULL;
}

///////////////////////////////////////////////////////////////////////////
// Remove the hook...
///////////////////////////////////////////////////////////////////////////
void WINAPI _RemoveHook()
{
	if(hHook){

		UnhookWindowsHookEx(hHook);

		hHook = NULL;
		hViewerWnd = NULL;
		OnKeyEvent = NULL;
	}
} 
