//----------------------------------------------------------------------//
#define WINAPI __stdcall //use the default windows api calling convention
//----------------------------------------------------------------------//
#include <windows.h>
#include <stdio.h>
//----------------------------------------------------------------------//
#define WH_KEYBOARD_LL   13
//----------------------------------------------------------------------//
LRESULT CALLBACK KeyboardProc(int code, WPARAM wParam, LPARAM lParam);
//----------------------------------------------------------------------//
BOOL WINAPI _InstallHook(HWND ViewerWnd);
void WINAPI _RemoveHook();
//----------------------------------------------------------------------//
