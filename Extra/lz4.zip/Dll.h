//----------------------------------------------------------------------//
#define EXP_FUNC __stdcall//use the default windows api calling convention
//----------------------------------------------------------------------//
#define WIN32_LEAN_AND_MEAN // Trim libraies.
#define VC_LEANMEAN         // Trim even further.
//----------------------------------------------------------------------//
#include <Windows.h>
#include <stdio.h>
//----------------------------------------------------------------------//
#include "lz4.h"
//----------------------------------------------------------------------//

//----------------------------------------------------------------------//
// Globals Functions
//----------------------------------------------------------------------//
int EXP_FUNC _Compress(const char* source, char* dest, int inputSize);
int EXP_FUNC _Decompress(const char* source, char* dest, int inputSize, int maxOutputSize);
