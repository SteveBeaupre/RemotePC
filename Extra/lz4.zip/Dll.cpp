#include "Dll.h"

/**************************************************
main procedure.....................................
**************************************************/
BOOL WINAPI DllMain(HINSTANCE hInst, DWORD fdwreason, LPVOID lpReserved)
{
    switch(fdwreason)
	{
    case DLL_PROCESS_ATTACH: break;
    case DLL_PROCESS_DETACH: break; 
    case DLL_THREAD_ATTACH:  break;
    case DLL_THREAD_DETACH:  break;
    }
    return TRUE;
}

int EXP_FUNC _Compress(const char* source, char* dest, int inputSize)
{
	return LZ4_compress(source, dest, inputSize);
}

int EXP_FUNC _Decompress(const char* source, char* dest, int inputSize, int maxOutputSize)
{
	return LZ4_decompress_safe(source, dest, inputSize, maxOutputSize);
}
